<?php
$style = 'content/stm_events/layouts/layout_1';

stm_motors_events_load_template($style);