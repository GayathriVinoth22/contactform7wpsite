<div class="comments-list review-comment-form">
	<?php comments_template( '/comments.php'); ?>
</div>