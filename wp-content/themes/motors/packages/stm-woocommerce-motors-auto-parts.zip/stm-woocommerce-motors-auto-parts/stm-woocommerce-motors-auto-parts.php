<?php
/**
Plugin Name: Motors - WooCommerce Auto Parts
Plugin URI: http://stylemixthemes.com/
Description: Woocommerce Motors Auto Parts Shop
Author: StylemixThemes
Author URI: https://stylemixthemes.com/
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Text Domain: stm-woocommerce-motors-auto-parts
Version: 1.0.3
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

define( 'STM_WCMAP_PATH', dirname( __FILE__ ) );
define( 'STM_WCMAP_INC_PATH', dirname( __FILE__ ) . '/inc/' );
define( 'STM_WCMAP_URL', plugins_url( '', __FILE__ ) );
define( 'STM_WCMAP', 'stm-woocommerce-category-megamenu' );

if ( ! is_textdomain_loaded( 'stm-woocommerce-category-megamenu' ) ) {
    load_plugin_textdomain( 'stm-woocommerce-category-megamenu', false, 'stm-woocommerce-category-megamenu/languages' );
}

require_once STM_WCMAP_INC_PATH . 'wcmap-ajax.php';
require_once STM_WCMAP_INC_PATH . 'setup.php';
require_once STM_WCMAP_INC_PATH . 'scripts_styles.php';
require_once STM_WCMAP_INC_PATH . 'woo-action-filter-calls.php';
require_once STM_WCMAP_INC_PATH . 'woo-attr-image.php';
require_once STM_WCMAP_INC_PATH . 'woo-cat-advert-banner.php';
require_once STM_WCMAP_INC_PATH . 'ClassWCMAPSearchFilter.php';
require_once STM_WCMAP_INC_PATH . 'functions.php';
require_once STM_WCMAP_INC_PATH . 'visual_composer.php';