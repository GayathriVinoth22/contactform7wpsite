<?php
/**
 * Created by PhpStorm.
 * User: dima
 * Date: 1/25/19
 * Time: 16:05
 */

if(class_exists('YITH_WCWL_Shortcode')) {
    ?>
    <div class="prod-wishlist heading-font">
        <?php echo do_shortcode('[yith_wcwl_add_to_wishlist]'); ?>
    </div>
    <?php
}