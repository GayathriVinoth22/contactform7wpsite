<?php
/**
 * Created by PhpStorm.
 * User: dima
 * Date: 1/25/19
 * Time: 15:44
 */

if(class_exists('YITH_Woocompare_Frontend')) {
    global $product;
    $compare = new YITH_Woocompare_Frontend();

    ?>
    <div class="prod-compare">
        <?php $compare->add_compare_link($product->get_id()); ?>
    </div>
<?php } ?>