<?php
/**
 * Created by PhpStorm.
 * User: dima
 * Date: 1/23/19
 * Time: 11:44
 */

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$css_class = (!empty($css)) ? apply_filters(VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class($css, ' ')) : '';

stm_wcmap_enqueue_scripts_styles('stm_wcmap_products_list', 'stm_wcmap_products_list');

$atts = array(
    'limit'        => $number_posts,
    'columns'      => $columns,
    'orderby'      => $orderby,
    'order'        => $order,
    'cat_operator' => 'IN',
);

$wc_prod = new WC_Shortcodes();
switch($product_type) {
    case "featured":
        echo $wc_prod::featured_products($atts);
        break;
    case "sale":
        echo $wc_prod::sale_products($atts);
        break;
    case "best_selling":
        $atts = array(
            'limit'        => $number_posts,
            'columns'      => $columns,
            'cat_operator' => 'IN',
            'best_selling' => 'best_selling'
        );
        echo $wc_prod::products($atts);
        break;
    case "top_rated":
        echo $wc_prod::top_rated_products($atts);
        break;
    default:
        echo $wc_prod::products($atts);

}
