/**
 * Created by Administrator on 12/01/2016.
 */

jQ