<?php
    require_once PLUGIN_SERVER_PATH.'/admin/post-type/function-init.php';
    require_once PLUGIN_SERVER_PATH.'/admin/vc-extension/vc-init.php';
    require_once PLUGIN_SERVER_PATH.'/admin/widgets/contact-info.php';
    require_once PLUGIN_SERVER_PATH.'/admin/rate/rating-input.php';
    require_once PLUGIN_SERVER_PATH.'/admin/rate/rating-output.php';
?>