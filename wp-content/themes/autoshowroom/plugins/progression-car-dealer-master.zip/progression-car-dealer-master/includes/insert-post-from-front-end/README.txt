=== Insert post from front-end with featured image ===
Contributors: Mohsin khan
Donate link:  
Tags: comments, custom posts, testimonial, news, reviews 
Requires at least: 3.0.1
Tested up to: 4.8
Stable tag: 4.8
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin is created for insert post from front-end, Using this plugin we can insert any type of post from front-end with featured image.

== Description ==

This plugin is created for insert post from front-end, Using this plugin we can insert any type of post from front-end with featured image.
And also we can pass post status in shortcode like publish,draft,pending etc.


== Installation ==

* Upload the directory '/insert-post-from-front-end/' to your WP plugins directory and activate from the Dashboard of the main blog.
* Activate the plugin through the 'Plugins' menu in WordPress
* And use shortcode on any page/post <code style="background-color:gray;">[Insert_post_from_frontEnd post_type="post" status="publish"]</code>.
* If you don't want to pass post status attribute then automatically post status "draft".
* If want to use shortcode on any template file then use <code> <?php echo do_shortcode('[Insert_post_from_frontEnd post_type="post" status="publish"]'); ?></code>



== Frequently Asked Questions ==
 None at this time

== Changelog ==

** V 1.0 **
Stable initial release

